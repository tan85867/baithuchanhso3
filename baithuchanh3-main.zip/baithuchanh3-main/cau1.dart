void ham() {
  print("Phạm Văn Thiên");
}

void main() {
  ham();
}
